@extends('layouts.app')

@section('content')

<div class="text-center">
  <h1>Selamat Datang!</h1>
</div>

@endsection
